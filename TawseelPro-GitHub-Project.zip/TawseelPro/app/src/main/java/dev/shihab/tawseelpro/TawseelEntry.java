package dev.shihab.tawseelpro;

import android.app.Application;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class TawseelEntry implements IXposedHookLoadPackage {
    private static final String TARGET = "com.smartapps.tawseeldelivery";
    private static final String MAIN = "com.smartapps.tawseeldelivery.MainActivity";

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;
        try {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam param) {
                        Application app = (Application) param.thisObject;
                        if (!TARGET.equals(app.getPackageName())) return;
                        try {
                            app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                                @Override public void onActivityCreated(Activity a, Bundle b) {}
                                @Override public void onActivityStarted(Activity a) {}
                                @Override public void onActivityResumed(Activity a) {
                                    if (MAIN.equals(a.getClass().getName())) OverlayController.attach(a);
                                }
                                @Override public void onActivityPaused(Activity a) { OverlayController.detach(a); }
                                @Override public void onActivityStopped(Activity a) {}
                                @Override public void onActivitySaveInstanceState(Activity a, Bundle b) {}
                                @Override public void onActivityDestroyed(Activity a) { OverlayController.detach(a); }
                            });
                        } catch (Throwable ignored) { }
                    }
                });
        } catch (Throwable ignored) { }
    }
}
