package dev.shihab.tawseelpro;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.Locale;

final class OverlayController {
    private static final String PREF = "tawseel_pro_local";
    private static final String TARGET = "com.smartapps.tawseeldelivery";
    private static Activity current;
    private static WindowManager wm;
    private static View floating;
    private static boolean expanded;
    private static boolean edgeHidden;
    private static int selectedCategory = -1;
    private static String filter = "";
    private static volatile String cloudKey = ""; // intentionally not persisted
    private static final Handler main = new Handler(Looper.getMainLooper());

    private OverlayController() {}

    static void attach(Activity activity) {
        if (activity == null || activity.isFinishing() || !TARGET.equals(activity.getPackageName())) return;
        if (current == activity && floating != null && floating.isAttachedToWindow()) return;
        detach(current);
        current = activity;
        wm = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
        if (!prefs().getBoolean("enabled", true)) return;
        createFloating();
    }

    static void detach(Activity activity) {
        if (activity == null || activity != current) return;
        try { if (wm != null && floating != null && floating.isAttachedToWindow()) wm.removeView(floating); } catch (Throwable ignored) {}
        floating = null; current = null; wm = null;
    }

    private static SharedPreferences prefs() {
        return current.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
    private static int dp(float v) { return (int)(v * current.getResources().getDisplayMetrics().density + 0.5f); }
    private static TextView text(String s, int size) {
        TextView t = new TextView(current); t.setText(s); t.setTextSize(size); t.setTextColor(0xfff2f3fa);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(8), dp(6), dp(8), dp(6)); return t;
    }
    private static Button button(String s) {
        Button b = new Button(current); b.setText(s); b.setTextSize(13); b.setAllCaps(false); return b;
    }

    private static void createFloating() {
        if (current == null || wm == null) return;
        LinearLayout root = new LinearLayout(current); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xee202433); root.setPadding(dp(4), dp(4), dp(4), dp(4));
        TextView bubble = text(edgeHidden ? "‹" : "⚡", edgeHidden ? 16 : 20);
        bubble.setBackground(round(0xff394363, 22));
        bubble.setOnClickListener(v -> { edgeHidden = false; expanded = !expanded; refreshFloating(); });
        root.addView(bubble, new LinearLayout.LayoutParams(dp(edgeHidden ? 25 : 52), dp(edgeHidden ? 46 : 54)));
        if (expanded && !edgeHidden) {
            TextView header = text("Tawseel Pro  •  120 أداة", 16);
            root.addView(header, new LinearLayout.LayoutParams(-1, dp(42)));
            LinearLayout controls = new LinearLayout(current); controls.setOrientation(LinearLayout.HORIZONTAL);
            Button hide = button("إخفاء"); hide.setOnClickListener(v -> { expanded=false; edgeHidden=true; refreshFloating(); });
            Button close = button("طيّ"); close.setOnClickListener(v -> { expanded=false; refreshFloating(); });
            Button search = button("بحث"); search.setOnClickListener(v -> promptSearch());
            controls.addView(hide, new LinearLayout.LayoutParams(0, dp(44), 1));
            controls.addView(close, new LinearLayout.LayoutParams(0, dp(44), 1));
            controls.addView(search, new LinearLayout.LayoutParams(0, dp(44), 1)); root.addView(controls);
            LinearLayout cats = new LinearLayout(current); cats.setOrientation(LinearLayout.HORIZONTAL);
            String[] categories = {"الكل","الذكاء المحلي","الأرباح والدراجة","التوصيل والملاحة","الإشعارات والتشخيص","الإنتاجية والإعدادات"};
            for (int i=0;i<categories.length;i++) { final int c=i-1; Button cb=button(categories[i]); cb.setTextSize(10); cb.setOnClickListener(v->{selectedCategory=c;refreshFloating();}); cats.addView(cb,new LinearLayout.LayoutParams(0,dp(42),1)); }
            root.addView(cats);
            ScrollView scroll = new ScrollView(current); LinearLayout list = new LinearLayout(current); list.setOrientation(LinearLayout.VERTICAL);
            for (int i=0;i<FeatureCatalog.ITEMS.length;i++) {
                final int index=i; String label=FeatureCatalog.ITEMS[i];
                if (selectedCategory>=0 && !FeatureCatalog.category(i).equals(categoryName(selectedCategory))) continue;
                if (!filter.isEmpty() && !label.toLowerCase(Locale.ROOT).contains(filter.toLowerCase(Locale.ROOT))) continue;
                Button item=button((i<60?"✦ ":"")+label); item.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
                item.setOnClickListener(v->runFeature(index)); list.addView(item,new LinearLayout.LayoutParams(-1,dp(44)));
            }
            scroll.addView(list); root.addView(scroll,new LinearLayout.LayoutParams(-1,dp(360)));
            TextView footer=text("محلي افتراضيًا • السحابي باختيارك",11); root.addView(footer);
        }
        floating=root;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams();
        lp.width=dp(expanded&&!edgeHidden?Math.min(370,(int)(current.getResources().getDisplayMetrics().widthPixels/current.getResources().getDisplayMetrics().density*.88)):edgeHidden?30:64);
        lp.height=expanded&&!edgeHidden?dp(560):dp(edgeHidden?52:64);
        lp.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL; lp.type=WindowManager.LayoutParams.TYPE_APPLICATION;
        lp.flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        lp.format=android.graphics.PixelFormat.TRANSLUCENT;
        try { lp.token=current.getWindow().getDecorView().getWindowToken(); wm.addView(floating,lp); } catch(Throwable e) { floating=null; }
    }
    private static android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private static String categoryName(int c){String[] n={"الذكاء المحلي","الأرباح والدراجة","التوصيل والملاحة","الإشعارات والتشخيص","الإنتاجية والإعدادات"};return c>=0&&c<n.length?n[c]:"";}
    private static void refreshFloating(){try{if(wm!=null&&floating!=null&&floating.isAttachedToWindow())wm.removeView(floating);}catch(Throwable ignored){}floating=null;createFloating();}

    private static void promptSearch(){EditText e=new EditText(current);e.setHint("اكتب اسم الأداة");new AlertDialog.Builder(current).setTitle("البحث في الأدوات").setView(e).setPositiveButton("بحث",(d,w)->{filter=e.getText().toString().trim();expanded=true;refreshFloating();}).setNegativeButton("إلغاء",null).show();}
    private static void runFeature(int i){
        if(i==107){promptSearch();return;} if(i==109){showSettings();return;} if(i==110){edgeHidden=true;expanded=false;refreshFloating();return;} if(i==111){edgeHidden=false;expanded=false;refreshFloating();return;} if(i==117){showAbout();return;} if(i==118){showPrivacy();return;} if(i==119){cloudSetup();return;}
        if(i==105){editRecord("ملاحظة", "notes");return;} if(i==106){editRecord("مهمة", "tasks");return;} if(i==39){currencyConvert();return;}
        if(i==60){recordAmount("دخل", "income");return;} if(i==61||i==62||i==63){recordAmount(i==61?"مصروف":i==62?"وقود":"صيانة", "expense");return;}
        if(i==64||i==65||i==72||i==73||i==74||i==75||i==76){calculator(i);return;}
        if(i==66||i==67||i==68||i==69||i==70||i==71||i==77||i==78||i==79){goalDialog(i);return;}
        if(i==80||i==81||i==84||i==85||i==88){localTextAction(i);return;}
        if(i>=95&&i<=104){diagnostic(i);return;}
        if(i==114){exportLocal();return;} if(i==115){copyReport();return;} if(i==116){new AlertDialog.Builder(current).setTitle("مسح البيانات المحلية").setMessage("سيحذف سجل الوحدة فقط، ولن يغيّر بيانات تطبيق التوصيل.").setPositiveButton("مسح",(d,w)->{prefs().edit().clear().apply();toast("تم مسح سجل الوحدة");}).setNegativeButton("إلغاء",null).show();return;}
        if(i==112||i==113){appearance(i);return;}
        if(i<60){smartFeature(i);return;}
        localTextAction(i);
    }
    private static void smartFeature(int i){
        String prompt="أدخل قيمة أو وصفًا مختصرًا"; if(i==1||i==3||i==4||i==8||i==10||i==23||i==25||i==26||i==27||i==29||i==54||i==55||i==56||i==57) prompt="أدخل الأرقام مفصولة بفواصل: قيمة, قيمة";
        EditText e=new EditText(current);e.setHint(prompt);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        new AlertDialog.Builder(current).setTitle(FeatureCatalog.ITEMS[i]+" • محلي").setMessage("المعالجة على الجهاز دون اتصال. لا يتم إرسال بيانات الطلبات.").setView(e).setPositiveButton("تحليل",(d,w)->{
            String input=e.getText().toString().trim(); String result=localAnalysis(i,input); new AlertDialog.Builder(current).setTitle("النتيجة").setMessage(result).setPositiveButton("نسخ",(dd,ww)->copy(result)).setNeutralButton("اسأل السحابي",(dd,ww)->cloudAsk(input)).setNegativeButton("إغلاق",null).show();
        }).setNegativeButton("إلغاء",null).show();
    }
    private static String localAnalysis(int i,String input){
        double[] nums=parseNumbers(input); DecimalFormat f=new DecimalFormat("#,##0.##");
        if(i==1||i==8||i==10||i==26||i==27||i==54||i==55||i==56||i==57){double sum=0;for(double n:nums)sum+=n;if(nums.length==0)return "لم أجد أرقامًا. أدخل مثلًا: 2500, 300, 200"; if(i==1||i==10||i==26||i==27){if(nums.length>=2)sum=nums[0]-nums[1];return "الناتج المحلي: "+f.format(sum)+" ريال يمني";}return "مجموع القيم: "+f.format(sum)+" ريال يمني\nعدد القيم: "+nums.length;}
        if(i==3&&nums.length>=2&&nums[1]!=0)return "ربح الساعة: "+f.format(nums[0]/nums[1])+" ريال/ساعة";
        if(i==4&&nums.length>=2&&nums[1]!=0)return "ربح الكيلومتر: "+f.format(nums[0]/nums[1])+" ريال/كم";
        if(input.isEmpty())return "ابدأ بإدخال بياناتك يدويًا. لا نقرأ معلومات خفية من التطبيق.";
        return "ملخص محلي:\n"+input+"\n\nاقتراح: سجّل الدخل والمصروفات بانتظام لتحصل على مقارنة واقعية. هذه أداة مساعدة وليست تنبؤًا مضمونًا.";
    }
    private static double[] parseNumbers(String s){try{String[] a=s.replace("،",",").split(",");double[] n=new double[a.length];for(int i=0;i<a.length;i++)n[i]=Double.parseDouble(a[i].trim());return n;}catch(Exception e){return new double[0];}}
    private static void currencyConvert(){EditText e=new EditText(current);e.setHint("المبلغ بالدولار أو الريال اليمني");new AlertDialog.Builder(current).setTitle("تحويل العملة • 1 USD = 530 YER").setView(e).setPositiveButton("تحويل",(d,w)->{try{double v=Double.parseDouble(e.getText().toString().trim());String result=new DecimalFormat("#,##0.##").format(v)+" USD = "+new DecimalFormat("#,##0.##").format(v*530)+" ريال يمني\n\nأو "+new DecimalFormat("#,##0.##").format(v)+" YER = "+new DecimalFormat("#,##0.####").format(v/530)+" USD";new AlertDialog.Builder(current).setMessage(result).setPositiveButton("نسخ",(dd,ww)->copy(result)).setNegativeButton("إغلاق",null).show();}catch(Exception ex){toast("أدخل رقمًا صحيحًا");}}).setNegativeButton("إلغاء",null).show();}
    private static void recordAmount(String title,String key){EditText e=new EditText(current);e.setHint("المبلغ بالريال اليمني");e.setInputType(8194);new AlertDialog.Builder(current).setTitle("تسجيل "+title).setView(e).setPositiveButton("حفظ",(d,w)->{try{double v=Double.parseDouble(e.getText().toString().trim());addTotal(key,v);append("ledger",title+": "+v+" YER");toast("تم تسجيل "+title);}catch(Exception ex){toast("أدخل مبلغًا صحيحًا");}}).setNegativeButton("إلغاء",null).show();}
    private static void addTotal(String key,double amount){double n=prefs().getFloat(key,0f)+(float)amount;prefs().edit().putFloat(key,(float)n).apply();}
    private static void calculator(int i){EditText e=new EditText(current);e.setHint("أدخل قيمتين مثل 3000, 12");new AlertDialog.Builder(current).setTitle(FeatureCatalog.ITEMS[i]).setMessage("للوقود: أدخل المسافة بالكيلومتر ثم معدل كم/لتر أو سعر اللتر بحسب الحاسبة.").setView(e).setPositiveButton("حساب",(d,w)->{double[] n=parseNumbers(e.getText().toString());String out;if(n.length<2||n[1]==0)out="أدخل قيمتين صحيحتين غير صفريتين.";else if(i==64||i==65)out="الناتج التقريبي: "+new DecimalFormat("#,##0.##").format(n[0]/n[1])+" (وحدة حسب المدخل)";else out="الناتج: "+new DecimalFormat("#,##0.##").format(n[0]/n[1]);new AlertDialog.Builder(current).setMessage(out).setPositiveButton("موافق",null).show();}).setNegativeButton("إلغاء",null).show();}
    private static void goalDialog(int i){String key=i==70?"goal_day":i==71?"goal_week":"goal_month";EditText e=new EditText(current);e.setHint("هدفك بالريال اليمني");e.setInputType(8194);new AlertDialog.Builder(current).setTitle(FeatureCatalog.ITEMS[i]).setView(e).setPositiveButton("حفظ",(d,w)->{try{prefs().edit().putFloat(key,Float.parseFloat(e.getText().toString())).apply();toast("تم حفظ الهدف");}catch(Exception ex){toast("قيمة غير صحيحة");}}).setNegativeButton("إلغاء",null).show();}
    private static void editRecord(String title,String key){EditText e=new EditText(current);e.setHint("اكتب هنا...");e.setMinLines(3);new AlertDialog.Builder(current).setTitle(title).setView(e).setPositiveButton("حفظ",(d,w)->{append(key,e.getText().toString());toast("تم الحفظ محليًا");}).setNegativeButton("إلغاء",null).show();}
    private static void localTextAction(int i){EditText e=new EditText(current);e.setHint("محتوى أو ملاحظة");e.setMinLines(3);new AlertDialog.Builder(current).setTitle(FeatureCatalog.ITEMS[i]).setView(e).setPositiveButton("معالجة",(d,w)->{String v=e.getText().toString();String result=i==82||i==83?"المسافة/الوقت المدخل: "+v:"تم حفظ/تنظيم النص محليًا:\n"+v;new AlertDialog.Builder(current).setMessage(result).setPositiveButton("نسخ",(dd,ww)->copy(result)).setNegativeButton("إغلاق",null).show();}).setNegativeButton("إلغاء",null).show();}
    private static void diagnostic(int i){if(i==95){if(Build.VERSION.SDK_INT>=33){boolean granted=current.checkSelfPermission("android.permission.POST_NOTIFICATIONS")==0;toast("إذن POST_NOTIFICATIONS: "+(granted?"ممنوح":"غير ممنوح"));}else toast("هذا الإصدار لا يستخدم إذن Android 13 الجديد.");return;}if(i==96){openSettings("android.settings.APP_NOTIFICATION_SETTINGS");return;}if(i==97){if(Build.VERSION.SDK_INT>=23){NotificationManager nm=(NotificationManager)current.getSystemService(Context.NOTIFICATION_SERVICE);toast("عدم الإزعاج: "+(nm.isNotificationPolicyAccessGranted()?"صلاحية السياسة ممنوحة":"تحقق من إعداد عدم الإزعاج"));}return;}if(i==98||i==99){openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);return;}if(i==100){append("diag","فحص إشعار: "+System.currentTimeMillis());toast("سُجل وقت الفحص محليًا");return;}if(i==101){new AlertDialog.Builder(current).setMessage("افحص إذن الإشعارات، قنوات التطبيق، عدم الإزعاج، وتوفير البطارية. الوحدة لا تعترض Firebase.").setPositiveButton("موافق",null).show();return;}if(i==102){toast("افتح إعدادات التطبيق واختبر إشعارًا رسميًا");return;}toast("Tawseel Pro 1.0 • Android "+Build.VERSION.RELEASE);}
    private static void openSettings(String action){try{Intent it=new Intent(action);it.setData(Uri.parse("package:"+TARGET));it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);current.startActivity(it);}catch(Exception e){openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);}}
    private static void appearance(int i){if(i==112){prefs().edit().putInt("size",(prefs().getInt("size",64)+8)%88).apply();toast("حُفظ حجم الزر. أعد فتح اللوحة لتطبيقه.");}else{float a=prefs().getFloat("alpha",.92f);prefs().edit().putFloat("alpha",a<=.45f?.92f:a-.15f).apply();toast("حُفظت الشفافية.");}}
    private static void showSettings(){String msg="العملة: الريال اليمني (YER)\nسعر الدولار المرجعي: 530 ريال\nالمعمارية: أدوات محلية أولًا\nالذكاء السحابي: اختياري\nالزر يظهر داخل التطبيق فقط.";new AlertDialog.Builder(current).setTitle("إعدادات Tawseel Pro").setMessage(msg).setPositiveButton("موافق",null).show();}
    private static void cloudSetup(){EditText url=new EditText(current);url.setText(prefs().getString("cloud_url","https://api.openai.com/v1/chat/completions"));url.setHint("رابط API متوافق");EditText key=new EditText(current);key.setHint("API key (لا يتم حفظه)");key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);LinearLayout l=new LinearLayout(current);l.setOrientation(1);l.addView(url);l.addView(key);new AlertDialog.Builder(current).setTitle("المساعد السحابي الاختياري").setMessage("قد يستهلك بيانات وقد تكون الخدمة مدفوعة. لا تُرسل تفاصيل الطلب أو موقعك. المفتاح يبقى في ذاكرة العملية فقط.").setView(l).setPositiveButton("حفظ الرابط",(d,w)->{String u=url.getText().toString().trim();if(!u.startsWith("https://")){toast("استخدم رابط HTTPS");return;}prefs().edit().putString("cloud_url",u).apply();cloudKey=key.getText().toString().trim();toast("حُفظ الرابط؛ المفتاح غير محفوظ على القرص.");}).setNegativeButton("إلغاء",null).show();}
    private static void cloudAsk(String query){if(cloudKey.isEmpty()){cloudSetup();toast("أدخل مفتاح الخدمة أولًا؛ لا يوجد مفتاح مضمّن.");return;}String endpoint=prefs().getString("cloud_url","");if(!endpoint.startsWith("https://")){toast("أضف رابط HTTPS في إعداد المساعد");return;}toast("يُرسل السؤال النصي فقط إلى مزودك السحابي...");new Thread(()->{String answer="تعذر الاتصال";HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+cloudKey);JSONObject body=new JSONObject();body.put("model","gpt-4o-mini");body.put("max_tokens",220);JSONArray messages=new JSONArray();messages.put(new JSONObject().put("role","system").put("content","أجب بالعربية باختصار. لا تطلب معلومات شخصية أو بيانات حسابات. مساعد عام لمندوب دراجة نارية في اليمن."));messages.put(new JSONObject().put("role","user").put("content",query.substring(0,Math.min(1800,query.length()))));body.put("messages",messages);try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}BufferedReader br=new BufferedReader(new InputStreamReader(c.getResponseCode()<400?c.getInputStream():c.getErrorStream(),StandardCharsets.UTF_8));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);JSONObject res=new JSONObject(sb.toString());answer=res.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");}catch(Exception ex){answer="فشل الاتصال: "+ex.getClass().getSimpleName();}finally{if(c!=null)c.disconnect();}final String a=answer;main.post(()->{if(current!=null&&!current.isFinishing())new AlertDialog.Builder(current).setTitle("المساعد السحابي").setMessage(a).setPositiveButton("نسخ",(d,w)->copy(a)).setNegativeButton("إغلاق",null).show();});}).start();}
    private static void showAbout(){new AlertDialog.Builder(current).setTitle("Tawseel Pro Toolkit").setMessage("وحدة إنتاجية محلية. لا تتدخل في الموقع أو Firebase أو إرسال الطلبات. دليل الأدوات 120 بندًا، منها 60 أداة ذكية محلية/تحليلية.").setPositiveButton("موافق",null).show();}
    private static void showPrivacy(){new AlertDialog.Builder(current).setTitle("الخصوصية").setMessage("الأرباح والملاحظات محفوظة محليًا داخل بيانات الوحدة. لا تُقرأ بيانات الطلبات الخفية. الاتصال السحابي لا يعمل تلقائيًا؛ عند استخدامه يرسل النص الذي تكتبه فقط إلى عنوان الخدمة الذي تختاره. لا تحفظ الوحدة مفتاح API في SharedPreferences.").setPositiveButton("موافق",null).show();}
    private static void append(String key,String value){String old=prefs().getString(key,"");String next=(old.isEmpty()?"":old+"\n")+System.currentTimeMillis()+" | "+value;prefs().edit().putString(key,next).apply();}
    private static void exportLocal(){String s=report();copy(s);toast("نسخ التقرير النصي؛ الصقه في ملف لحفظه.");}
    private static void copyReport(){copy(report());toast("تم نسخ التقرير");}
    private static String report(){return "Tawseel Pro - تقرير محلي\nالدخل: "+prefs().getFloat("income",0)+" YER\nالمصروفات: "+prefs().getFloat("expense",0)+" YER\nالصافي: "+(prefs().getFloat("income",0)-prefs().getFloat("expense",0))+" YER\nسعر الدولار المرجعي: 530 YER\n"+prefs().getString("ledger","");}
    private static void copy(String s){android.content.ClipboardManager cm=(android.content.ClipboardManager)current.getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText("Tawseel Pro",s));}
    private static void toast(String s){if(current!=null)Toast.makeText(current,s,Toast.LENGTH_SHORT).show();}
}
