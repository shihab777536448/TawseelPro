# Tawseel Pro Toolkit (NPatch Integrated module)

Target scope: `com.smartapps.tawseeldelivery` only. Java 17, compileSdk 34, minSdk 27, classic Xposed API 82 entry point.

## Features in this starter release

- App-only floating panel, drag-free side button, collapse and edge-minimize/restore.
- Search and category filtering for 120 catalog entries (60 smart/local-first entries).
- Local income/expense/fuel/maintenance ledger in module-private SharedPreferences.
- Local note/task capture, simple numeric calculators, goal storage, report-to-clipboard.
- Passive notification permission/settings diagnostics. **No hooks on Firebase, location, notification delivery, order submission, or mock-location detection.**
- Optional user-configured HTTPS OpenAI-compatible chat endpoint. No key is bundled; key is held only in process memory, not persisted. Cloud use may cost money and data; query is capped and only user-entered text is sent.

## Build in GitHub Actions from phone

1. Create a GitHub repository and upload this folder's files preserving paths (including `.github/workflows/build.yml`).
2. In GitHub, open **Actions** and allow workflows if prompted.
3. Run **Build Tawseel Pro Xposed Module** with **Run workflow**, or push to `main`/`master`.
4. Open the completed workflow run → **Artifacts** → download `TawseelPro-module-debug` → extract the APK.

The workflow uses JDK 17 and Gradle 8.4. The APK is the module APK, not a rebuilt copy of the delivery app.

## Integrated NPatch steps

1. Back up the original delivery app data/account access before uninstalling it; patched signatures differ.
2. Start from a clean, store-original APK. Do not patch an already patched APK.
3. In NPatch select **Integrated** mode and the module APK built by this repository (bundled modules selector shown in your screenshot).
4. Keep debug-related patch options disabled unless NPatch's own documentation specifically requires otherwise.
5. Patch, install the resulting APK, then launch the target. The module hooks only the target package and only adds its panel to `MainActivity`.
6. For updates/removal in Integrated mode, patch a clean original again with the new/omitted module.

## Notifications troubleshooting

This module intentionally does not intercept FCM or NotificationManager. If the integrated app still receives order updates in-app but has no notification, test a clean original patched with this module alone. Check Android App info → Notifications, notification channels, Do Not Disturb, and battery restrictions. Foreground Flutter FCM notifications may require the app's own Dart foreground handler to create a local notification; a third-party hook cannot safely reconstruct unknown app payloads. If the clean-original APK also loses notifications, report it as a patch/runtime compatibility issue and keep the store APK for work until resolved.

## Backup checklist

- Keep the store APK / APKS if legally and technically available; this does not back up app-private data.
- Use Samsung Smart Switch and Google device backup for general phone data, but do not assume they restore this app's private storage.
- Verify account phone/password/OTP access and server-synced earnings before uninstalling.
- Export/record anything important that exists only inside the app.
- Preserve the original app installer and do not overwrite it with a patched copy.

## Safety and limits

The unit is an Android client-side helper. It does not change server-side records, spoof location, bypass fraud checks, auto-accept/submit orders, or guarantee earnings. The feature catalog contains 120 labeled entries; this release implements shared functional workflows for recording, calculation, local notes, diagnostics, and reports, rather than claiming every entry is a distinct AI model. The cloud AI requires your own provider credentials and can incur usage charges.
